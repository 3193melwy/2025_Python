class Mammal:
    def __init__(self, species, age, name, job):
        self.species = species
        self.age = age
        self.name = name
        self.job = job

class Person(Mammal):
    def __init__(self, species, age, name, job):
        super().__init__(species, age, name, job)

m1 = Mammal("동물", 30, "Kim", "Engineer")
p1 = Person("동물", 30, "Kim", "Engineer")

print(f"포유류 : {m1.species} {m1.age} {m1.name} {m1.job}")
print(f"사람 : {p1.species} {p1.age} {p1.name} {p1.job}")