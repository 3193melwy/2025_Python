class Book:
    def __init__(self, title, isbn):
        self.__itle = title
        self.__isbn = isbn
    def __repr__(self):
        return "ISBN: "+self.__isbn+"; TITLE: "+self.__itle
    
book = Book("The Python Tutorial", "0123456")
print(book)