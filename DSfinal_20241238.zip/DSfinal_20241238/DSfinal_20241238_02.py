import tkinter as tk


# --------------------------------
# 클래스 정의
# --------------------------------
class Person:
    """사람 클래스"""
    def __init__(self, name: str):
        self.name = name  # 이름 저장


class HobbyPerson(Person):
    """클래스 (Person 상속)"""
    def __init__(self, name: str):
        super().__init__(name)
        self.classes = [] 

    def add_hobby(self, hobbies: str):
        """취미 등록 (중복 방지)"""
        if hobbies not in self.classes:
            self.classes.append(hobbies)

    def clear_hobbies(self):
        """모든 취미 초기화"""
        self.classes.clear()


# --------------------------------
# tkinter GUI 초기화
# --------------------------------
root = tk.Tk()
root.title("문제 2")
root.geometry("380x260")

# Student 객체 생성
stu = HobbyPerson("김덕성")

# 학생 이름 표시 라벨
title = tk.Label(root, text=f"이름: {stu.name}", font=("맑은 고딕", 11, "bold"))
title.pack(pady=6)


# --------------------------------
# 체크박스 프레임
# --------------------------------
frm = tk.Frame(root)
frm.pack(pady=8, anchor="center")

# 체크박스 변수 (0=선택 안됨, 1=선택됨)
var_py  = tk.IntVar(value=0)
var_ai  = tk.IntVar(value=0)
var_ds  = tk.IntVar(value=0)

# 체크박스 생성
cb1 = tk.Checkbutton(frm, text="게임",      variable=var_py)
cb2 = tk.Checkbutton(frm, text="독서",          variable=var_ai)
cb3 = tk.Checkbutton(frm, text="운동", variable=var_ds)

# 그리드 배치
cb1.grid(row=0, column=0, padx=8, pady=4)
cb2.grid(row=0, column=1, padx=8, pady=4)
cb3.grid(row=0, column=2, padx=8, pady=4)


# --------------------------------
# 결과 표시 라벨
# --------------------------------
result = tk.StringVar(value="취미를 선택하고 [등록하기]를 누르세요.")
lb = tk.Label(root, textvariable=result, wraplength=340, justify="left")
lb.pack(pady=8)


# --------------------------------
# 버튼 클릭 이벤트 함수
# --------------------------------
def register_courses():
    """선택된 취미 등록"""
    stu.clear_hobbies() 
    if var_py.get(): stu.add_hobby("게임")
    if var_ai.get(): stu.add_hobby("독서")
    if var_ds.get(): stu.add_hobby("운동")

    if stu.classes:
        result.set(f"현재 선택된 취미 : {', '.join(stu.classes)}")
    else:
        result.set("선택된 과목이 없습니다.")


def reset_all():
    """체크박스 초기화 + 취미 목록 초기화"""
    var_py.set(0)
    var_ai.set(0)
    var_ds.set(0)
    stu.clear_hobbies()
    result.set("모든 선택을 해제했습니다.")


# --------------------------------
# 버튼 프레임
# --------------------------------
btn_frame = tk.Frame(root)
btn_frame.pack(pady=6)

tk.Button(btn_frame, text="등록하기", command=register_courses).pack(side="left", padx=8)
tk.Button(btn_frame, text="초기화",   command=reset_all).pack(side="left", padx=8)


# --------------------------------
# tkinter 이벤트 루프 시작
# --------------------------------
root.mainloop()