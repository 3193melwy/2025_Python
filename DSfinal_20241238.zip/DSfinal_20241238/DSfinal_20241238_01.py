# tkinter GUI를 활용한 도형 선택 및 그리기 프로그램
# Shape 추상 클래스 상속 → Rectangle, Circle 구현
# 선택한 도형을 Canvas에 그림과 동시에 면적, 둘레 계산

import tkinter as tk
import math


# --------------------------------
# 추상 클래스 정의
# --------------------------------
class DrawableShape:
    """도형 추상 클래스"""
    def __init__(self, x, y):
        self.x, self.y = x, y  # 도형 위치 좌표

    def area(self):
        """면적 계산 (추상 메서드)"""
        raise NotImplementedError

    def perimeter(self):
        """둘레 계산 (추상 메서드)"""
        raise NotImplementedError

    def draw(self, canvas):
        """Canvas에 도형 그리기 (추상 메서드)"""
        raise NotImplementedError


# --------------------------------
# 사각형 클래스
# --------------------------------
class Rectangle(DrawableShape):
    def __init__(self, x, y, w, h):
        super().__init__(x, y)  # 부모 클래스 초기화
        self.w, self.h = w, h   # 너비, 높이

    def area(self):
        return self.w * self.h

    def perimeter(self):
        return 2 * (self.w + self.h)

    def draw(self, canvas):
        """Canvas에 사각형 그리기"""
        canvas.create_rectangle(
            self.x, self.y, self.x + self.w, self.y + self.h, fill="tomato"
        )


# --------------------------------
# 원 클래스
# --------------------------------
class Circle(DrawableShape):
    def __init__(self, x, y, r):
        super().__init__(x, y)
        self.r = r  # 반지름

    def area(self):
        return math.pi * self.r ** 2

    def perimeter(self):
        return 2 * math.pi * self.r

    def draw(self, canvas):
        """Canvas에 원 그리기"""
        canvas.create_oval(
            self.x - self.r, self.y - self.r, self.x + self.r, self.y + self.r, fill="skyblue"
        )


# --------------------------------
# tkinter GUI 초기화
# --------------------------------
root = tk.Tk()
root.title("문제1")

# 도형 그릴 Canvas
canvas = tk.Canvas(root, width=300, height=220, bg="white")
canvas.pack(pady=6)

# 라디오 버튼 선택 값과 정보 표시 변수
var = tk.StringVar(value="rect")  # 기본 선택: 사각형
info = tk.StringVar(value="도형을 선택하고 그리기를 누르세요.")  # 면적/둘레 표시용

tk.Label(root, textvariable=info).pack()


# --------------------------------
# 라디오 버튼 (사각형 / 원)
# --------------------------------
frm = tk.Frame(root)
frm.pack(pady=6, anchor="center")

tk.Radiobutton(frm, text="사각형", value="rect", variable=var).pack(side="left", padx=6)
tk.Radiobutton(frm, text="원", value="circle", variable=var).pack(side="left", padx=6)


# --------------------------------
# 버튼 클릭 이벤트 함수
# --------------------------------
def draw_shape():
    canvas.delete("all")  # 기존 도형 삭제
    if var.get() == "rect":
        s = Rectangle(50, 50, 100, 60)  # 사각형 객체 생성
    else:
        s = Circle(150, 110, 40)        # 원 객체 생성

    s.draw(canvas)  # 도형 Canvas에 그림
    # 면적과 둘레 계산 후 표시 (소수점 2자리)
    info.set(f"면적={s.area():.2f}, 둘레={s.perimeter():.2f}")


# 그리기 버튼
tk.Button(root, text="그리기", command=draw_shape).pack(pady=6)


# --------------------------------
# tkinter 이벤트 루프 시작
# --------------------------------
root.mainloop()