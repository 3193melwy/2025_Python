# 코드로 형식 지정됨
class DSstudent:
  def __init__(self, stu_id =  0, name= None) :  #Student 객체 생성자
    self.stu_id = stu_id
    self.name = name    #인스턴트 변수

  def show_info(self): 
    print(f"학번 : {self.stu_id} 이름 : {self.name} ")

stu = DSstudent("20241238", "백민진")

stu.show_info()