class Inventory:
    def __init__(self, stock):
        self.stock = stock
        self.__stock= 0  # 인스턴스 변수 (각 계좌별로 관리)
        print(f"{self.stock}새 상품이 등록되었습니다.")

    # 접근자 (Getter)
    def get__balance(self):
        return self.__stock
    # 설정자 (Setter)
    def set__stock(self, amount):
        if amount >= 0:
            self.__stock = amount
        else:
            print("재고는 0이 될 수 없습니다.")

    # 입금 메서드
    def add_stock(self, amount):
        if amount > 0:
            self__stock += amount
            print(f"{amount}가 입고 되었습니다.")
        return self.stock

    # 출금 메서드
    def remove_stock(self, amount):
        if 0 < amount <= self.stock:
            self.stock -= amount
            print(f"{amount}가 출고되었습니다.")
        return self.stock

# 실행 예시
item1 = Inventory("고구마")
item1.add_stock(10)
item1.remove_stock(3)
print("현재 재고 수량 : ", item1.get__stock1())

item1.set__stock1(20)
print("수정된 재고 수량 : ", item1.get__stock1)