#로그인

from tkinter import *  # tkinter 모듈의 모든 클래스를 불러온다

def print_fields():  # "로그인" 버튼 클릭 시 실행될 함수를 정의한다
    # 오타 수정: e1.grt() → e1.get()
    print("아이디 : %s\n패스워드 : %s" % (e1.get(), e2.get()))  # 입력된 아이디와 패스워드를 콘솔에 출력한다

root = Tk()  # 기본 윈도우 창을 생성한다

Label(root, text = "아이디").grid(row=0)  # "아이디" 라벨을 첫 번째 행에 배치한다
Label(root, text = "패스워드").grid(row=1)  # "패스워드" 라벨을 두 번째 행에 배치한다

e1 = Entry(root)  # 아이디를 입력받을 Entry 위젯을 생성한다
e2 = Entry(root)  # 패스워드를 입력받을 Entry 위젯을 생성한다
e1.grid(row=0, column=1)  # 아이디 입력창을 첫 번째 행, 두 번째 열에 배치한다
e2.grid(row=1, column=1)  # 패스워드 입력창을 두 번째 행, 두 번째 열에 배치한다

Button(root, text='로그인', command=print_fields).grid(row=3, column=0, sticky=W, pady=4)  # "로그인" 버튼을 생성하고 왼쪽 정렬로 배치한다
Button(root, text='취소', command=root.quit).grid(row=3, column=1, sticky=W, pady=4)  # "취소" 버튼을 생성하고 클릭 시 프로그램 종료

root.mainloop()