class DSstudent:
  def __init__(self, stu_id =  0, name= None) :  #Student 객체 생성자
    self.stu_id = stu_id
    self.name = name    #인스턴트 변수

  def show_info(self): 
    print(f"학번 : {self.stu_id} 이름 : {self.name} ")

class UndergraduateStudent(DSstudent):
  def  __init__(self, stu_id =  0, name= None, major = None) :
    super().__init__(stu_id, name)
    self.major = major

  def introduce(self): 
    print(f"저는 학부생 {self.stu_id}입니다. 전공은 {self.major}입니다. ")

class GraduationStudent(DSstudent):
  def __init__(self, stu_id= 0,  name= None, advisior = None) :
    super().__init__(stu_id, name)
    self.advisior = advisior
  def introduce(self): 
    print(f"저는 대학원생 {self.stu_id}입니다. 지도교수님은 {self.advisior}입니다. ")

stu1 = UndergraduateStudent("202501", "김민수", "컴퓨터공학")
stu2 = GraduationStudent("202401", "이수정", "홍길동")

stu1.show_info()
stu1.introduce()
stu2.show_info()
stu2.introduce()