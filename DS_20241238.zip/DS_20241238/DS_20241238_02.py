#ch09_06

class BankAccount(object):  # BankAccount 클래스 정의 (object는 Python 3에서 생략 가능)
    interest_rate = 0.3  # 클래스 변수: 이자율 (사용되지는 않지만 모든 계좌에 공통 적용 가능)

    def __init__(self, owner, balance): 
        self.owner = owner 
        self.__balance = balance 

    def get_balance(self):   #getter 메서드
        return self.__balance
    def set_balance(amount) :
        

# BankAccount 클래스의 인스턴스 생성
user1 = BankAccount("Chung", "1111111", 1000)  # 이름 "Chung", 계좌번호 "1111111", 초기 잔고 1000

print("초기 잔고:", user1.balance)  # 초기 잔고 출력
user1.deposit(500)  # 500 입금
print("저축 후 잔고:", user1.balance)  # 입금 후 잔고 출력
user1.withdraw(200)  # 200 출금
print("인출 후 잔고:", user1.balance)  # 출금 후 잔고 출력
user1.withdraw(10000)  # 잔고보다 많은 금액 출금 시도 → 실패 메시지 출력